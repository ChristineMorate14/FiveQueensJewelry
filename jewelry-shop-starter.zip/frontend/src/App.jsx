import React, {useEffect, useState} from 'react';

const API = (path)=>'/api'+path;

function App(){
  const [products,setProducts] = useState([]);
  const [cart,setCart] = useState([]);
  const [message,setMessage] = useState('');

  useEffect(()=>{ fetch(API('/products')).then(r=>r.json()).then(setProducts); },[]);

  function addToCart(p){
    const existing = cart.find(c=>c.product_id===p.id);
    if(existing){
      setCart(cart.map(c=>c.product_id===p.id?{...c,quantity:c.quantity+1}:c));
    } else {
      setCart([...cart,{product_id:p.id, name:p.name, price:p.price, quantity:1}]);
    }
  }

  async function checkout(){
    const order = {customer_name:'Guest', customer_email:'', items: cart};
    const res = await fetch(API('/orders'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(order)});
    if(res.ok){ setMessage('Order placed!'); setCart([]); } else { setMessage('Checkout failed'); }
  }

  return (<div style={{fontFamily:'Arial, sans-serif',padding:20}}>
    <h1>Elegant Gems - Jewelry Shop (Demo)</h1>
    <div style={{display:'flex',gap:20}}>
      <div style={{flex:2}}>
        <h2>Products</h2>
        <ul>
          {products.map(p=>(
            <li key={p.id} style={{marginBottom:12}}>
              <strong>{p.name}</strong> - ₱{p.price.toFixed(2)} <br/>
              <small>{p.description}</small><br/>
              <button onClick={()=>addToCart(p)}>Add to cart</button>
            </li>
          ))}
        </ul>
      </div>
      <div style={{flex:1}}>
        <h2>Cart</h2>
        <ul>
          {cart.map(c=>(
            <li key={c.product_id}>{c.name} x {c.quantity}</li>
          ))}
        </ul>
        <button onClick={checkout} disabled={cart.length===0}>Checkout</button>
        <div style={{marginTop:10}}>{message}</div>
        <h3>Admin Reports</h3>
        <AdminReports />
      </div>
    </div>
  </div>);
}

function AdminReports(){
  const [year,setYear] = useState(new Date().getFullYear());
  const [month,setMonth] = useState(new Date().getMonth()+1);
  const [report,setReport] = useState(null);

  async function load(){
    const q = `/analytics/best-sellers?year=${year}&month=${month}&limit=5`;
    const res = await fetch('/api'+q);
    if(res.ok) setReport(await res.json());
  }

  useEffect(()=>{ load(); },[]);

  return (<div>
    <label>Year: <input value={year} onChange={e=>setYear(e.target.value)} style={{width:80}}/></label>
    <label style={{marginLeft:8}}>Month: <input value={month} onChange={e=>setMonth(e.target.value)} style={{width:60}}/></label>
    <button onClick={load} style={{marginLeft:8}}>Load</button>
    {report && (<div style={{marginTop:8}}>
      <div>Report period: {report.start} — {report.end}</div>
      <ol>
        {report.rows.map(r=>(
          <li key={r.id}>{r.name} — qty: {r.total_quantity} — sales: ₱{Number(r.total_sales).toFixed(2)}</li>
        ))}
      </ol>
    </div>)}
  </div>);
}

export default App;
