const express = require('express');
const bodyParser = require('body-parser');
const Database = require('better-sqlite3');
const path = require('path');
const cors = require('cors');

const db = new Database(path.join(__dirname,'shop.sqlite'));
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Serve static frontend if placed in backend/public
app.use(express.static(path.join(__dirname,'public')));

// --- Products ---
app.get('/api/products', (req,res)=>{
  const rows = db.prepare('SELECT * FROM products').all();
  res.json(rows);
});

app.get('/api/products/:id', (req,res)=>{
  const row = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if(!row) return res.status(404).json({error:'Not found'});
  res.json(row);
});

// --- Orders: create a simple order (cart checkout) ---
app.post('/api/orders', (req,res)=>{
  const {customer_name, customer_email, items} = req.body;
  if(!items || !Array.isArray(items) || items.length===0) return res.status(400).json({error:'No items'});
  const insertOrder = db.prepare('INSERT INTO orders(customer_name,customer_email,created_at) VALUES(?,?,?)');
  const info = insertOrder.run(customer_name||'Guest', customer_email||'', new Date().toISOString());
  const orderId = info.lastInsertRowid;
  const insertItem = db.prepare('INSERT INTO order_items(order_id,product_id,quantity,price) VALUES(?,?,?,?)');
  const getProduct = db.prepare('SELECT price FROM products WHERE id = ?');
  const updateStock = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?');
  const itemsSaved = [];
  const txn = db.transaction((items)=>{
    for(const it of items){
      const prod = getProduct.get(it.product_id);
      const qty = Number(it.quantity) || 1;
      insertItem.run(orderId, it.product_id, qty, prod.price);
      updateStock.run(qty, it.product_id);
      itemsSaved.push({product_id: it.product_id, quantity: qty});
    }
  });
  try{
    txn(items);
    res.json({order_id: orderId, items: itemsSaved});
  }catch(err){
    res.status(500).json({error: String(err)});
  }
});

// --- Analytics: best-sellers for month ---
app.get('/api/analytics/best-sellers', (req,res)=>{
  // query params: year, month (1-12), limit
  const year = parseInt(req.query.year) || (new Date()).getFullYear();
  const month = parseInt(req.query.month); // optional
  const limit = parseInt(req.query.limit) || 10;
  let start, end;
  if(month && month>=1 && month<=12){
    start = new Date(year, month-1, 1).toISOString();
    end = new Date(year, month, 1).toISOString();
  } else {
    // whole year
    start = new Date(year,0,1).toISOString();
    end = new Date(year+1,0,1).toISOString();
  }
  const stmt = db.prepare(`
    SELECT p.id, p.name, p.sku, SUM(oi.quantity) as total_quantity, SUM(oi.quantity * oi.price) as total_sales
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    JOIN products p ON p.id = oi.product_id
    WHERE o.created_at >= ? AND o.created_at < ?
    GROUP BY p.id
    ORDER BY total_quantity DESC
    LIMIT ?
  `);
  const rows = stmt.all(start, end, limit);
  res.json({start, end, rows});
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=>console.log('Backend running on',PORT));
