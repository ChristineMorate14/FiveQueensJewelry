Backend notes:
- Uses better-sqlite3 for simplicity (synchronous, zero-config).
- init_db.js wipes existing shop.sqlite and creates schema.
- seed.js inserts sample products and orders to demonstrate analytics.
