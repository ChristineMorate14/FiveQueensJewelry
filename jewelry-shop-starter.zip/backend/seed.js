const Database = require('better-sqlite3');
const path = require('path');
const db = new Database(path.join(__dirname,'shop.sqlite'));

const products = [
  {name:'Classic Gold Ring', sku:'GR-001', description:'14k gold ring, elegant design', price:129.99, stock:20},
  {name:'Pearl Earrings', sku:'PE-002', description:'Freshwater pearl studs', price:79.50, stock:35},
  {name:'Silver Necklace', sku:'SN-003', description:'Sterling silver pendant necklace', price:99.00, stock:15},
  {name:'Diamond Pendant', sku:'DP-004', description:'CZ diamond pendant on chain', price:249.00, stock:5},
  {name:'Bracelet Charm', sku:'BC-005', description:'Charm bracelet set', price:59.99, stock:40}
];

const insert = db.prepare('INSERT INTO products(name,sku,description,price,stock) VALUES(?,?,?,?,?)');
const insertMany = db.transaction((arr)=>{
  for(const p of arr) insert.run(p.name,p.sku,p.description,p.price,p.stock);
});
insertMany(products);
console.log('Seeded products.');

// seed sample orders across months for analytics demo
const now = new Date();
const insertOrder = db.prepare('INSERT INTO orders(customer_name,customer_email,created_at) VALUES(?,?,?)');
const insertItem = db.prepare('INSERT INTO order_items(order_id,product_id,quantity,price) VALUES(?,?,?,?)');

function makeDate(year,month,day){
  return new Date(year, month-1, day).toISOString();
}

// create orders in different months
const sampleOrders = [
  {date: makeDate(2025,9,5), items:[{pid:1,q:2},{pid:2,q:1}]},
  {date: makeDate(2025,9,20), items:[{pid:3,q:1}]},
  {date: makeDate(2025,10,2), items:[{pid:1,q:1},{pid:5,q:3}]},
  {date: makeDate(2025,10,15), items:[{pid:2,q:2}]},
  {date: makeDate(2025,11,4), items:[{pid:4,q:1},{pid:1,q:1}]},
  {date: makeDate(2025,11,12), items:[{pid:5,q:2},{pid:2,q:1}]}
];

for(const o of sampleOrders){
  const info = insertOrder.run('Customer','customer@example.com', o.date);
  for(const it of o.items){
    const prod = db.prepare('SELECT price FROM products WHERE id = ?').get(it.pid);
    insertItem.run(info.lastInsertRowid, it.pid, it.q, prod.price);
    db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(it.q, it.pid);
  }
}
console.log('Sample orders seeded.');
