# Jewelry Shop - Full Stack Starter

This is a starter full-stack e-commerce jewelry shop you can push to GitHub and run locally.
Frameworks used:
- Backend: Node.js + Express + SQLite (better-sqlite3)
- Frontend: React (Vite or simple setup)

Features:
- Product catalog (seeded sample jewelry items)
- Shopping cart & simple checkout (no payment gateway)
- Orders stored in SQLite
- Monthly best-seller analytics endpoint and simple admin dashboard

## Quick start (Linux / macOS / Windows WSL)

1. Backend
```bash
cd backend
npm install
npm run init-db    # creates SQLite DB and tables
npm run seed       # seed sample products and sample orders
npm start
```
Server runs on http://localhost:4000

2. Frontend (development)
```bash
cd frontend
npm install
npm run dev
```
Or build and serve static from backend (production):
```
cd frontend
npm run build
# copy frontend/dist into backend/public (or configure)
```

## How best-seller report works
- Orders and order_items record purchases with timestamps.
- Analytics endpoint: `GET /analytics/best-sellers?year=2025&month=11&limit=5`
- It returns top products by quantity sold for that month.

Push this repo to GitHub:
```bash
git init
git add .
git commit -m "Initial jewelry shop starter"
# create remote and push
```

This starter is intended to be extended with authentication, payments, product images, and real deployment.
